﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Connection.Not_Mapped
{
    public class CustomerInfoVM
    {
        public string Type { get; set; }
        public string CustomerName { get; set; }
        public string CustomerNameRight { get; set; }
        public string Address1 { get; set; }
        public string Address1Right { get; set; }
        public string Address2 { get; set; }
        public string Address2Right { get; set; }
        public string Address3 { get; set; }
        public string Address3Right { get; set; }
        public string DateAsToday { get; set; }

    }
}
