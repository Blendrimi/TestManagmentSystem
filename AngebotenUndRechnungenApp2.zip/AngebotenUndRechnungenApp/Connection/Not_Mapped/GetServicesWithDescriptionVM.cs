﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Connection.Not_Mapped
{
    public class GetServicesWithDescriptionVM
    {
        public string Vlera1 { get; set; }
        public string Vlera2 { get; set; }
    }
}
