﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Connection.Not_Mapped
{
    public class GetChart2DataVM
    {
        public int YearName { get; set; }
        public int MonthName { get; set; }
        public decimal Price { get; set; }

    }
}
