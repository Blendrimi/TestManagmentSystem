﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Connection.Not_Mapped
{
   public class GetAllInvoicesPricesVM
    {
        public int NumberOfItem { get; set; }
        public decimal Price { get; set; }
    }
}
