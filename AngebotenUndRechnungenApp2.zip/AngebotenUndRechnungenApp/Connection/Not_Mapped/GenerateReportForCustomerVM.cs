﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Connection.Not_Mapped
{
    public class GenerateReportForCustomerVM
    {
        public int ID { get; set; }
        public string Type { get; set; }
        public string CustomerName { get; set; }
        public string ProjectName { get; set; }
        public string Builder { get; set; }
        public string CleaningLocation { get; set; }


    }
}
