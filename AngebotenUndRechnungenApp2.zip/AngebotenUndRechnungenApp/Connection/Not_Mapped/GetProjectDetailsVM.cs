﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Connection.Not_Mapped
{
    public class GetProjectDetailsVM
    {
        public string ProjectName { get; set; }
        public string Builder { get; set; }
        public string Vlera1 { get; set; }
        public string NoOfReferenceOrInvoice { get; set; }
        public string Vlera2 { get; set; }
        public string Vlera3 { get; set; }
        public string CleaningLocation { get; set; }
    }
}
