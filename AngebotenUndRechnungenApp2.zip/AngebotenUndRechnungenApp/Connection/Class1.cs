﻿using System;

namespace Connection
{
    public class Class1
    {
    }
}
